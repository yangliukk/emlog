<?php 
	phpinfo();
	?>